package com.example.demo;

import java.sql.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Accounts;
import com.example.demo.layer2.Transactions;
import com.example.demo.layer3.StatementJPARepository;
import com.example.demo.layer4.StatementService;

@SpringBootTest
class StatementApplicationTests {
	
	@Autowired
	StatementJPARepository stmtRepo;
	
	@Test
	void contextLoads() {
		Accounts a = new Accounts();
		a.setAccountNumber(12345678);
		a.setAccountHolderName("Sumitaa");
		a.setAccountHolderAddress("Nerul West Navi Mumbai");
		a.setCurrentBalance(50000.00);
		a.setEmail("sumitaa@email.com");
		a.setPassword("sumit123");
		   Transactions t1 = new Transactions();
		   Transactions t2 = new Transactions();
		   Transactions t3 = new Transactions();
		   
		   t1.setTransType('D');
		   Date d = new Date(2022,03,02);
		   t1.setTransDate(d);
		   t1.setTrans_amount(5000.00);
		   t1.setRemainingBalance(45000.00);
		   t1.setRefAccount("987654321");
		   t1.setAccount(a);
		   
		   t2.setTransType('D');
		   t2.setTransDate(d);
		   t2.setTrans_amount(5000.00);
		   t2.setRemainingBalance(40000.00);
		   t2.setRefAccount("987654321");
		   t2.setAccount(a);
		   
		   t3.setTransType('D');
		   t3.setTransDate(d);
		   t3.setTrans_amount(5000.00);
		   t3.setRemainingBalance(35000.00);
		   t3.setRefAccount("987654321");
		   t3.setAccount(a);
		   
		   
		   stmtRepo.save(a);
		   
		
		
		
	}

}
