package com.example.demo.layer4;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Transactions;

@Service
public class StatementServiceImplementation implements StatementService {

	@Override
	public List<Transactions> fetchMonthlyTransactions(int year, int month) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transactions> fetchYearlyTransactions(int year) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transactions> fetchCustomTransactions(Date fromDate, Date toDate) {
		// TODO Auto-generated method stub
		return null;
	}

}
