package com.example.demo.layer4;
import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.Transactions;

@Service
public interface StatementService {
	
	public List<Transactions> fetchMonthlyTransactions(int year,int month);
	
	public List<Transactions> fetchYearlyTransactions(int year);
	
	public List<Transactions> fetchCustomTransactions(Date fromDate, Date toDate);
	

}
