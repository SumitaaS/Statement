package com.example.demo.layer3;

import java.io.Serializable;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatementJPARepository<T, Integer > extends CrudRepository<T, Integer> {

}
