package com.example.demo.layer2;
import java.sql.Date;
import javax.persistence.*;

@Entity
@Table(name="Transactions")
public class Transactions {
	@Id
	@GeneratedValue
	@Column(name="trans_id")
	private int transId;
	@Column(name="trans_date")
	private Date transDate;
	@Column(name="trans_type")
	private char transType;
	@Column(name="trans_amount")
	private double trans_amount;
	@Column(name="remaining_balance")
	private double remainingBalance;
	@Column(name="ref_account")
	private String refAccount;
	
	@ManyToOne
	@JoinColumn(name="account_no")
	private Accounts account;
	
	public Accounts getAccount() {
		return account;
	}
	public void setAccount(Accounts account) {
		this.account = account;
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}
	public char getTransType() {
		return transType;
	}
	public void setTransType(char transType) {
		this.transType = transType;
	}
	public double getTrans_amount() {
		return trans_amount;
	}
	public void setTrans_amount(double trans_amount) {
		this.trans_amount = trans_amount;
	}
	public double getRemainingBalance() {
		return remainingBalance;
	}
	public void setRemainingBalance(double remainingBalance) {
		this.remainingBalance = remainingBalance;
	}
	public String getRefAccount() {
		return refAccount;
	}
	public void setRefAccount(String refAccount) {
		this.refAccount = refAccount;
	}

}
